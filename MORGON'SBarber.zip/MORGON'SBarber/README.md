# Barbearia
Projeto em Java - Barbearia: BarberShop  projeto sendo realizado em JavaForms no netbeans utilizando a estrutura MVC. Objetivo é encaminhar um email para o cliente notificando valor data e horario do seu agendamento.




##  Para realização desse projeto foi utilizado:

  - Netbeans  <br>
  - Java aplication para visual JFrames<br>
  - Orientação Objeto<br>
  - Padrão MVC <br>
  
  Ainda será implementado o banco de dados.... 

## Para acessar o sistema é necessario acesso com logim e senha tela de login:

### Tela de login

- Campo de Usuario 
- Campo de senha
- Botão

![Primeira tela](/_interface/Tela%20Login.jpg "Tela de login")



### Tela de Menu

- Campo de Cadastro
- Campo de Operação
- Campo de Relatorio

![Segunda tela](/_interface/Tela%20Menu%20Princiapal.jpg  "Tela de menu")

### Tela de Agenda

- Campo de Id
- Campo de Cliente
- Campo de Serviço
- Campo de Valor
- Campo de Data
- Campo de Hora
- Campo de Texto 
- Campo de Agendamentos
- Botão para enviar email.


![Terceira tela](/_interface/Agenda1.png "Tela de Agendamento")




#### Proximo passo implementação do banco de dados 12/2020!


