package model.DAO;

/**
 *
 * @author AMORGON
 */
public class PersonDAO {
    
}
