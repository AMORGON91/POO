package model.DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author AMORGON
 */
public class Conection {
    
    public Connection getConnection() throws SQLException{
        /**
         * Conexao com o banco de dados do postgreSQL ( ou outra escolha)
         * parametros: link da conexao, usuario e senha do servidor do banco de dados
         */
        Connection conn = DriverManager.getConnection("jdbc:postgresql:localhost:5432/barbershopMORGON", "postgres", "postgres");
        return conn;
        
    }
    
}
