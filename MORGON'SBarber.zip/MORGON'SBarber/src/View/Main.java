/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package View;

import java.text.ParseException;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.Agendamento;
import model.Cliente;
import model.Servico;
import model.Usuario;

/**
 *
 * @author AMORGON
 */
public class Main {
   public static void main(String[]args){
       String nome = "Fernando";
       System.out.println(nome);
       
       Servico servico = new Servico(1, "Barba", 40);
               
       System.out.println(servico.getDescricao());
       System.out.println(servico.getValor());
       
       Cliente cliente = new cliente (1,"Marcos",'M', "999096661", "Rua dos Bigodes 35");
       System.out.println(cliente);
       
       Usuario usuario = new Usuario(1, "Barbeiro", "123456" );
       System.out.println(usuario);
       
       try {
           Agendamento agendamento = new Agendamento (1,cliente, servico, 40, "08/12/2020  14:00" );
           System.out.println( agendamento.getCliente().getNome());
       } catch (ParseException ex) {
           Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
       }
       
       
        
       
   }

    private static class cliente extends Cliente {

        public cliente(int i, String marcos, char c, String string, String rua_dos_Bigodes_35) {
        }
    }
}
