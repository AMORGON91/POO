package controller;

import controller.helper.LoginHelper;
import model.Usuario;
import model.dao.UsuarioDAO;
import View.Login;
import View.MenuPrincipal;

/**
 *
 * @author AMORGON
 */
public class LoginController {

    private final Login view;
    private final LoginHelper helper;

    public LoginController(Login view) {
        this.view = view;
        this.helper = new LoginHelper(view);
    }
    
    public void entrarNoSistema() {
         
        //má prática, caso tenha vários campos tem  que usar gettext para verificar um por um
        String nome = view.getTextUser().getText();
        String senha = view.gettextSenha().getText();
        
        Usuario modelo = new Usuario(0, nome, senha);
        
        // pegar um usuario da view
        Usuario usuario = helper.obterModelo();
        
        // pesquisar usuario no banco
        UsuarioDAO usuarioDAO = new UsuarioDAO();
        Usuario usuarioAutenticado = usuarioDAO.selectPorNomeESenha(usuario);
        
        // se o usuario da view tiver o mesmo usuario e senha que o usuario vindo do banco redirecionar para  o menu principal
        // senao mostrar uma mensagem ao usuario "usuario ou senha invalidos"
        if (usuarioAutenticado != null) {
            // navegar menu principal
            MenuPrincipal menu = new MenuPrincipal();
            menu.setVisible(true);
            view.dispose();
        } else {
            view.exibeMensagem("Usuario ou Senha invalidos!");
        }
    }

    public void fizTarefa() {
        System.out.println("Busquei algo do BD");
        
        this.view.exibeMensagem("Executei o fiz tarefa");
    }

    public void FizTarefa() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
