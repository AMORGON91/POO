package controller.helper;

/**
 *
 * @author AMORGON
 */
public interface IHelper {

    public abstract Object obterModelo();
    
    public abstract void limparTela();
}
